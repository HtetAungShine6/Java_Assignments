
//Htet Aung Shine
//6530145
//Sec-541

package mQ2_6530145;

public class Graduate extends Student{
	
	private String thesisTitle;
	private int[] scores = new int[3];
	
	Graduate(){
		
	}
	
	Graduate(String id, String firstname, String lastname){
		super(id,firstname,lastname);
	}

	public int[] getScores() {
		return scores;
	}

	public void setScores(int[] scores) {
		this.scores = scores;
	}

	public String getThesisTitle() {
		return thesisTitle;
	}

	public void setThesisTitle(String title) {
		this.thesisTitle = title;
	}
	
	@Override
    public boolean setScore(int testNumber, int score) {
        if (testNumber >= 0 && testNumber < scores.length && score >= 0 && score <= 10) {
            scores[testNumber] = score;
            return true;
        }
        return false;
    }
	
	@Override
	public int totalScore() {
		int total = 0;
		for(int i=0; i<scores.length; i++) {
			total += scores[i];
		}
		return total/3;
	}
	
	@Override
	public String toString() {
		return super.getId() +" Graduate " + totalScore();
	}
}
