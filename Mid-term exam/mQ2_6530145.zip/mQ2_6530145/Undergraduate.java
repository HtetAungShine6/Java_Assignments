
//Htet Aung Shine
//6530145
//Sec-541

package mQ2_6530145;

public class Undergraduate extends Student{
	
	private String seniorprojectTitle;
	private int[] scores = new int[5];

	Undergraduate(){
		
	}
	
	Undergraduate(String id, String firstname, String lastname){
		super(id, firstname, lastname);
	}

	public int[] getScores() {
		return scores;
	}

	public void setScores(int[] scores) {
		this.scores = scores;
	}

	public String getSeniorprojectTitle() {
		return seniorprojectTitle;
	}

	public void setSeniorprojectTitle(String title) {
		this.seniorprojectTitle = title;
	}
	
	@Override
    public boolean setScore(int testNumber, int score) {
        if (testNumber >= 0 && testNumber < scores.length && score >= 0 && score <= 5) {
           scores[testNumber] = score;
            return true;
        }
        return false;
    }
	
	@Override
	public int totalScore() {
		int total = 0;
		for(int i=0; i<scores.length; i++) {
			total += scores[i];
		}
		return total/5;
	}
	
	@Override
	public String toString() {
		return super.getId() +" Undergraduate " + totalScore();
	}
}
