
//Htet Aung Shine
//6530145
//Sec-541

package mQ2_6530145;

public class Student {
	private String id;
	private String firstname;
	private String lastname;
	private int[] scores = new int[5];
	
	Student(){
		
	}
	
	Student(String id, String firstname, String lastname){
		this.id = id;
		this.firstname = firstname;
		this.lastname = lastname;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getFirstname() {
		return firstname;
	}

	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}

	public String getLastname() {
		return lastname;
	}

	public void setLastname(String lastname) {
		this.lastname = lastname;
	}

	public int[] getScores() {
		return scores;
	}

	public void setScores(int[] scores) {
		this.scores = scores;
	}
	
	public int getScore(int testNumber){
		if(testNumber >= 0) {
			return testNumber;
		}else {
			return -1;
		}
	}
	
	public boolean setScore(int testNumber, int score) {
		scores[testNumber] = score;
		if(testNumber >= 0 && testNumber < scores.length) {
			return true;
		}else {
			return false;
		}
	}
	
	public int totalScore() {
		int total = 0;
		for(int i=0; i<scores.length; i++) {
			total += scores[i];
		}
		return total;
	}
	
	public String toString() {
		return "Student id is "+id+"\nStudent's Firstname: "+firstname+"\nStudent's Lastname: "+lastname;
	}
}
