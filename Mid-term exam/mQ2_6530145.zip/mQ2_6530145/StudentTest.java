
//Htet Aung Shine
//6530145
//Sec-541

package mQ2_6530145;


import java.util.Arrays;

public class StudentTest {

	public static void main(String[] args) {
		
		Student student = new Student("6530145", "Htet Aung", "Shine");
		Undergraduate undergraduate = new Undergraduate("23857081", "James", "Arthur");
		Graduate graduate = new Graduate("17461915", "Java", "Programming");
		
		student.setScore(0,0);
		student.setScore(1,0);
		student.setScore(2,0);
		student.setScore(3,0);
		student.setScore(4,0);
		
		undergraduate.setScore(0,15);
		undergraduate.setScore(1,2);
		undergraduate.setScore(2,3);
		undergraduate.setScore(3,7);
		undergraduate.setScore(4,1);
		
		graduate.setScore(0,10);
		graduate.setScore(1,15);
		graduate.setScore(2,10);

		//Student
		System.out.println("=================== Student ===================");
		System.out.println(student);
		System.out.println("Student's Scores: " + Arrays.toString(student.getScores())); 
		System.out.println("Student's Total scores : "+ student.totalScore());
		System.out.println();
		
		//Undergraduate
		System.out.println("=================== Undergraduate ===================");
		System.out.println(undergraduate);
		System.out.println("Undergraduate's ID: " + undergraduate.getId());
		System.out.println("Undergraduate's First Name: " + undergraduate.getFirstname());
		System.out.println("Undergraduate's Last Name: " + undergraduate.getLastname());
		System.out.println("Undergraduate's Scores: "+ Arrays.toString(undergraduate.getScores()));
		System.out.println("Undergraduate's Total Scores: " + undergraduate.totalScore());
		System.out.println();
		
		//Graduate
		System.out.println("=================== Graduate ===================");
		System.out.println(graduate);
		System.out.println("Graduate's ID: " + graduate.getId());
		System.out.println("Graduate's First Name: " + graduate.getFirstname());
		System.out.println("Graduate's Last Name: " + graduate.getLastname());
		System.out.println("Graduate's Scores: "+ Arrays.toString(graduate.getScores()));
		System.out.println("Graduate's Total Scores: " + graduate.totalScore());

	}

//	Output
//	=================== Student ===================
//	Student id is 6530145
//	Student's Firstname: Htet Aung
//	Student's Lastname: Shine
//	Student's Scores: [0, 0, 0, 0, 0]
//	Student's Total scores : 0
//
//	=================== Undergraduate ===================
//	23857081 Undergraduate 1
//	Undergraduate's ID: 23857081
//	Undergraduate's First Name: James
//	Undergraduate's Last Name: Arthur
//	Undergraduate's Scores: [0, 2, 3, 0, 1]
//	Undergraduate's Total Scores: 1
//
//	=================== Graduate ===================
//	17461915 Graduate 6
//	Graduate's ID: 17461915
//	Graduate's First Name: Java
//	Graduate's Last Name: Programming
//	Graduate's Scores: [10, 0, 10]
//	Graduate's Total Scores: 6

}
